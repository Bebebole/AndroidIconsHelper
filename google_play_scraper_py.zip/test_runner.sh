#!/bin/bash

#Script to run both test frameworks

pytest

behave